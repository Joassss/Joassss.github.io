# QuaBot

Wat we zijn? Een geavanceerde discord bot. We hebben alles om een discord server op jou manier te maken, de manier hoe jij het wilt. Of dat nou is door middel van moderatie, tickets, reaction roles of iets anders: we hebben het voor je.

## Features
Ontzettend veel, we willen er zoveel mogelijk. En als ze er zijn, zijn ze perfect. Klaar om door vele servers gebruikt te worden, omdat ze niet mogen falen. Dus wat zijn de features?
- Reaction Roles
- Tickets
- Muziek
- Moderatie
- Beheer
- Welkom
- Audits
- Aanpasbaar

En ontzettend veel meer, alleen dat past niet hier.