# Enable Developer Mode

> Last edited: 1/23/2022 at 11:52AM

Developer mode is one of those discord features that is a must. You can copy channel, message, role and guild id's and they are used in quabot all the time. It's literally the core of quabot. So how do you enable it?

### Enabling
1. Open discord and go to settings.
2. Scroll down until you see the Advanced tab.
3. Click Advanced and look for Developer Mode.
4. Enable it, you will now see a 3rd option, ignore it.
5. To check if it works, right-click a message and see if it says "Copy ID" at the bottom of the context menu.

*If you still have questions, or are experiencing errors, go to our [Support Discord](https://discord.quabot.net).*