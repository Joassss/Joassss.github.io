# Commands

- [Fun Commands](/commands/fun)
- [Info Commands](/commands/info)
- [Management Commands](/commands/management)
- [Misc Commands](/commands/misc)
- [Moderation Commands](/commands/moderation)
- [Music Commands](/commands/music)
- [Support Commands](/commands/support)