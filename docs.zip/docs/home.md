# QuaBot

What we are? An advanced multipurpose discord bot. It has all you need to create a discord server your way, the way you want it to be. Whether that is through the moderation module, tickets, reaction roles, or any other feature you need: we have it.

<<<<<<< Updated upstream
## Features
=======
### FAQ
- How do I set up reaction roles? - [Link](/modules/reactions)
- How can I enable developer mode? - [Link](/enable-dev-mode)
- What commands do you have? - [Link](/commands)

### Features
>>>>>>> Stashed changes
Loads of them, we like to add as many as we can. And when we add them, we make sure they are perfect. Ready to be used by loads of servers, since we can't afford them to fail. So what are the features?
- Reaction Roles
- Tickets
- Music
- Moderation
- Management
- Welcome
- Audits
- Configurable

And a lot more, but it just doesn't fit here.

## Wiki
This is the QuaBot wiki. If you need help or can't find something there is probably something about it here.

### FAQ
- How do i setup reaction roles? - [Link](/modules/reactions)
- How can i enable developer mode? - [Link](/enable-dev-mode)
- What commands do you have? - [Link](/commands)