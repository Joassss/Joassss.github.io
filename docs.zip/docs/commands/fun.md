# Fun Commands

> Last edited: 1/22/2022 at 10:23PM

Fun commands are commands used to get funny images, play games and more to come soon.

#### `/cat`
Get an image of a cat.

#### `/coin`
Flip a coin.

#### `/dog`
Get an image of a dog.

#### `/meme`
Get a meme.

#### `/quiz`
Play a quiz.

#### `/reddit`
Get images from subreddits.   

#### `/rps`
Play rock, paper, scissors.

#### `/type`
Play a typing game.