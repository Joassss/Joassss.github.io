# Misc Commands

> Last edited: 1/23/2022 at 1:46PM

These commands give funny pictures, games and more.

### `/afk [toggle/status/reset] (status)`
Set your afk status, toggle afk and reset afk.


### `/avatar (user)`
Get a user's avatar or your own.

### `/color [hex-color]`
Visualize a color.

### `/discriminator [discriminator]` 
Get all users with a discriminator.

### `/divide [number] [number]` 
Divide two numbers.

### `/members` 
Get the guild's membercount.

### `/multiply [number] [number]`
Multiply two numbers.

### `/power [number] [number]`
Get a number to the power of a number.

### `/servericon `
Get the server's icon.

### `/subtract [number] [number]`
Subtract two numbers.

### `/sum [number] [number]`
Sum of two numbers.