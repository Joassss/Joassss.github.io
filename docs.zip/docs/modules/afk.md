# Afk Module

> Last edited: 1/23/2022 at 7:17PM

The AFK module is a really interesting concept. Lets see how it works.

### How does it work?
Users can run `/afk toggle` to go afk. When users are afk, whenever someone mentions them, they will be informed that that user is afk. With `/afk status` a user can set a message that will be sent when mentioned. When using `/afk reset` you can reset your message and status.


*If you still have questions, or are experiencing errors, go to our [Support Discord](https://discord.quabot.net).*