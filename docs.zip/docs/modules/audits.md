> [!NOTE]
> This feature is being updated in a future release, information may be outdated soon.
# Audits Module

> Last edited: 1/23/2022 at 8:07PM

Log deleted messages, role updates and all sorts of other events.

### How does it work?
You setup a log channel, `/config` -> Configure Channels -> Log Channel -> mention the channel. Whenever an event happens, message gets deleted, user get banned, messages get cleared it will be saved to this channel to be recalled at a later time. 

### Things to note
* Ignored channels are coming.
* Toggles for events are coming.
* More stuff incoming!

*If you still have questions, or are experiencing errors, go to our [Support Discord](https://discord.quabot.net).*