> [!NOTE]
> This feature is being updated in a future release, information may be outdated soon.

# Welcome Module

> Last edited: 1/23/2022 at 8:34PM

Setup welcome messages and join roles.

### How does it work?
Go to `/config` -> Configure Channels -> Welcome Channel -> Mention the channel. Welcome messages are now enabled. Disable them in the Toggle Features tab of `/config`. Join roles are enabled by default, toggle them in the Toggle Features tab of `/config`. Configure the roles in the Configure Roles tab of `/config`.

*If you still have questions, or are experiencing errors, go to our [Support Discord](https://discord.quabot.net).*